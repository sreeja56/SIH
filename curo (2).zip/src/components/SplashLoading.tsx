import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BellRing, 
  Camera, 
  Mic, 
  Check, 
  X, 
  ArrowRight, 
  ArrowLeft, 
  FolderHeart, 
  ShieldCheck, 
  Sparkles,
  HeartPulse,
  ChevronRight
} from 'lucide-react';
import { AppPermissions, Language } from '../types';
import { translations } from '../i18n/translations';
import { GramArogyaLogo } from './common/GramArogyaLogo';
import { GoogleMapPin } from './common/GoogleMapPin';

interface SplashLoadingProps {
  language: Language;
  onLanguageChange?: (language: Language) => void;
  onComplete: (permissions: AppPermissions) => void;
}

export const SplashLoading: React.FC<SplashLoadingProps> = ({ 
  language, 
  onLanguageChange, 
  onComplete 
}) => {
  const t = translations[language];

  // Stage: 'brand' (Swiggy-style app opening splash) -> 'permissions' (one-by-one prompts)
  const [stage, setStage] = useState<'brand' | 'permissions'>('brand');
  const [brandProgress, setBrandProgress] = useState<number>(0);

  // Permission step index:
  // 0: Notifications, 1: Camera, 2: Media, 3: Microphone, 4: Location, 5: Summary
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [direction, setDirection] = useState<number>(1);

  const [permissionsState, setPermissionsState] = useState<AppPermissions>({
    notificationsAllowed: null,
    cameraAllowed: null,
    mediaAllowed: null,
    voiceAllowed: null,
    microphoneAllowed: null,
    locationAllowed: null,
  });

  // Automatically progress the brand splash screen (like Swiggy / top apps)
  useEffect(() => {
    if (stage !== 'brand') return;

    const intervalTime = 40;
    const totalDuration = 2200; // 2.2 seconds display
    const increment = (intervalTime / totalDuration) * 100;

    const interval = setInterval(() => {
      setBrandProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setStage('permissions');
          return 100;
        }
        return prev + increment;
      });
    }, intervalTime);

    return () => clearInterval(interval);
  }, [stage]);

  // Transition immediately if user taps anywhere on brand splash or clicks continue
  const handleSkipBrandSplash = () => {
    setStage('permissions');
  };

  // Step-by-step permissions in EXACT requested order:
  // 1. Notifications, 2. Camera, 3. Media, 4. Microphone, 5. Location
  const stepsConfig = [
    {
      id: 'notifications',
      stepNum: 1,
      badgeText: 'Health Alerts & Alarms',
      badgeClass: 'bg-amber-100 text-amber-900 border-amber-200',
      iconBoxClass: 'bg-amber-50 border-amber-200 text-amber-600',
      renderIcon: () => <BellRing className="w-8 h-8 text-amber-600 animate-bounce" />,
      title: t.stepNotificationTitle || 'Notifications & Alarms',
      heading: t.stepNotificationHeading || 'Allow curo to send health alerts & alarms?',
      desc: t.stepNotificationDesc || 'Sends timely 30-minute doctor appointment reminders, critical medicine dosage alarms, village vaccination camp alerts, and emergency response updates.',
      benefit: t.stepNotificationBenefit || '30-minute appointment reminders & daily medicine dosage alarms',
      keyName: 'notificationsAllowed' as const,
      onRequestBrowser: async () => {
        if (typeof window !== 'undefined' && 'Notification' in window) {
          try {
            await Notification.requestPermission();
          } catch (err) {
            console.log('Notification permission handled:', err);
          }
        }
      }
    },
    {
      id: 'camera',
      stepNum: 2,
      badgeText: 'Camera Scanner',
      badgeClass: 'bg-blue-100 text-blue-800 border-blue-200',
      iconBoxClass: 'bg-blue-50 border-blue-200 text-[#007ceb]',
      renderIcon: () => <Camera className="w-8 h-8 text-[#007ceb]" />,
      title: t.stepCameraTitle || 'Camera Access',
      heading: t.stepCameraHeading || 'Allow curo to take pictures & scan documents?',
      desc: t.stepCameraDesc || 'Allows you to take clear photos of doctor prescriptions, handwritten notes, medicine strips, lab reports, and visible symptoms for instant AI reading.',
      benefit: t.stepCameraBenefit || 'Instant prescription scanning & medicine dosage reading',
      keyName: 'cameraAllowed' as const,
      onRequestBrowser: async () => {
        if (navigator?.mediaDevices?.getUserMedia) {
          try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
            stream.getTracks().forEach(track => track.stop());
          } catch (err) {
            console.log('Camera permission prompt handled:', err);
          }
        }
      }
    },
    {
      id: 'media',
      stepNum: 3,
      badgeText: 'Medical Files & Gallery',
      badgeClass: 'bg-purple-100 text-purple-800 border-purple-200',
      iconBoxClass: 'bg-purple-50 border-purple-200 text-purple-600',
      renderIcon: () => <FolderHeart className="w-8 h-8 text-purple-600" />,
      title: t.stepMediaTitle || 'Media & Storage Access',
      heading: t.stepMediaHeading || 'Allow curo to access photos & medical files?',
      desc: t.stepMediaDesc || 'Allows you to upload existing lab test PDFs, blood report pictures from your device gallery, and keep encrypted medical discharge summaries offline.',
      benefit: t.stepMediaBenefit || 'Upload lab reports from gallery & offline medical vault',
      keyName: 'mediaAllowed' as const,
      onRequestBrowser: async () => {
        if (navigator?.storage?.persist) {
          try {
            await navigator.storage.persist();
          } catch (err) {
            console.log('Storage persist handled:', err);
          }
        }
      }
    },
    {
      id: 'microphone',
      stepNum: 4,
      badgeText: 'Dr. Curo AI Voice & Mic',
      badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      iconBoxClass: 'bg-emerald-50 border-emerald-200 text-[#00a651]',
      renderIcon: () => (
        <div className="relative flex items-center justify-center">
          <Mic className="w-8 h-8 text-[#00a651]" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
        </div>
      ),
      title: t.stepVoiceTitle || 'Microphone & Voice Access',
      heading: t.stepVoiceHeading || 'Allow curo to record audio & listen?',
      desc: t.stepVoiceDesc || 'Allows you to speak directly to Dr. Curo, your AI voice triage assistant in Telugu, Hindi, or English. Designed specifically so you can consult without typing.',
      benefit: t.stepVoiceBenefit || 'Voice-first symptom triage in your mother tongue without typing',
      keyName: 'voiceAllowed' as const,
      onRequestBrowser: async () => {
        if (navigator?.mediaDevices?.getUserMedia) {
          try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            stream.getTracks().forEach(track => track.stop());
          } catch (err) {
            console.log('Microphone permission prompt handled:', err);
          }
        }
      }
    },
    {
      id: 'location',
      stepNum: 5,
      badgeText: 'Location Service',
      badgeClass: 'bg-sky-100 text-sky-800 border-sky-200',
      iconBoxClass: 'bg-sky-50 border-sky-200 text-[#007ceb]',
      renderIcon: () => <GoogleMapPin size={34} />,
      title: t.stepLocationTitle || 'Location Access',
      heading: t.stepLocationHeading || 'Allow curo to access this device’s location?',
      desc: t.stepLocationDesc || 'Allows Dr. Curo to locate your village, calculate exact distance to nearest Primary Health Centres (PHC), sub-centres, village ASHA workers, and route 108 emergency ambulances.',
      benefit: t.stepLocationBenefit || 'Nearest rural clinics & 108 emergency ambulance dispatch',
      keyName: 'locationAllowed' as const,
      onRequestBrowser: async () => {
        if (navigator?.geolocation?.getCurrentPosition) {
          navigator.geolocation.getCurrentPosition(
            () => {},
            (err) => console.log('Location permission handled:', err),
            { timeout: 4000, maximumAge: 60000 }
          );
        }
      }
    }
  ];

  const totalSteps = stepsConfig.length;
  const isSummaryStep = currentStepIndex >= totalSteps;
  const currentConfig = stepsConfig[currentStepIndex];

  // Handle granting current permission
  const handleAllowCurrent = async () => {
    if (!currentConfig) return;
    
    // Call browser trigger and wait for prompt response
    try {
      await currentConfig.onRequestBrowser();
    } catch (e) {
      console.warn('Browser permission request caught:', e);
    }

    const updatedPermissions = {
      ...permissionsState,
      [currentConfig.keyName]: true,
    };

    // If voice/mic permission, sync microphoneAllowed
    if (currentConfig.keyName === 'voiceAllowed') {
      updatedPermissions.microphoneAllowed = true;
    }

    setPermissionsState(updatedPermissions);
    setDirection(1);

    if (currentStepIndex < totalSteps - 1) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      // Finished all 5 steps -> go to summary
      setCurrentStepIndex(totalSteps);
    }
  };

  // Handle skipping / denying current permission
  const handleSkipCurrent = () => {
    if (!currentConfig) return;

    const updatedPermissions = {
      ...permissionsState,
      [currentConfig.keyName]: false,
    };

    // If voice/mic permission, sync microphoneAllowed
    if (currentConfig.keyName === 'voiceAllowed') {
      updatedPermissions.microphoneAllowed = false;
    }

    setPermissionsState(updatedPermissions);
    setDirection(1);

    if (currentStepIndex < totalSteps - 1) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      // Finished all 5 steps -> go to summary
      setCurrentStepIndex(totalSteps);
    }
  };

  // Allow all remaining permissions in one tap
  const handleAllowAllRemaining = () => {
    const fullPermissions: AppPermissions = {
      notificationsAllowed: permissionsState.notificationsAllowed ?? true,
      cameraAllowed: permissionsState.cameraAllowed ?? true,
      mediaAllowed: permissionsState.mediaAllowed ?? true,
      voiceAllowed: permissionsState.voiceAllowed ?? true,
      microphoneAllowed: permissionsState.microphoneAllowed ?? true,
      locationAllowed: permissionsState.locationAllowed ?? true,
    };

    // Trigger remaining browser permissions
    stepsConfig.forEach(step => {
      if (permissionsState[step.keyName] === null) {
        step.onRequestBrowser();
      }
    });

    setPermissionsState(fullPermissions);
    setCurrentStepIndex(totalSteps);
  };

  // Step back to previous permission
  const handlePreviousStep = () => {
    if (currentStepIndex > 0) {
      setDirection(-1);
      setCurrentStepIndex(prev => prev - 1);
    }
  };

  // Complete and enter login
  const handleFinalFinish = () => {
    const finalPermissions: AppPermissions = {
      notificationsAllowed: permissionsState.notificationsAllowed ?? false,
      cameraAllowed: permissionsState.cameraAllowed ?? false,
      mediaAllowed: permissionsState.mediaAllowed ?? false,
      voiceAllowed: permissionsState.voiceAllowed ?? false,
      microphoneAllowed: permissionsState.voiceAllowed ?? permissionsState.microphoneAllowed ?? false,
      locationAllowed: permissionsState.locationAllowed ?? false,
    };
    onComplete(finalPermissions);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-b from-[#007ceb] via-[#0284c7] to-[#00a651] text-white p-4 sm:p-6 overflow-y-auto select-none">
      {/* Decorative Rural Health Waves */}
      <div className="absolute inset-0 opacity-15 pointer-events-none">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path d="M0,25 Q25,50 50,25 T100,25 L100,100 L0,100 Z" fill="white" />
        </svg>
      </div>

      {/* Top Header Bar: Only shown during permissions stage to keep opening splash 100% clean like Swiggy */}
      {stage === 'permissions' ? (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md mx-auto flex items-center justify-between z-20 pt-2"
        >
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold uppercase tracking-wider text-white border border-white/30 shadow-xs">
            🇮🇳 Rural Healthcare Platform
          </span>

          {/* Quick Language Selector */}
          {onLanguageChange && (
            <div className="flex items-center gap-1 bg-white/20 backdrop-blur-md p-1 rounded-full border border-white/30">
              <button
                onClick={() => onLanguageChange('en')}
                className={`px-2.5 py-0.5 rounded-full text-xs font-bold transition-all ${
                  language === 'en' ? 'bg-white text-[#007ceb] shadow-xs' : 'text-white/80 hover:text-white'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => onLanguageChange('te')}
                className={`px-2.5 py-0.5 rounded-full text-xs font-bold transition-all ${
                  language === 'te' ? 'bg-white text-[#00a651] shadow-xs' : 'text-white/80 hover:text-white'
                }`}
              >
                తెలుగు
              </button>
              <button
                onClick={() => onLanguageChange('hi')}
                className={`px-2.5 py-0.5 rounded-full text-xs font-bold transition-all ${
                  language === 'hi' ? 'bg-white text-[#007ceb] shadow-xs' : 'text-white/80 hover:text-white'
                }`}
              >
                हिंदी
              </button>
            </div>
          )}
        </motion.div>
      ) : (
        <div className="h-8" />
      )}

      {/* STAGE 1: APP OPENING BRAND SPLASH SCREEN (Swiggy / Top Mobile Apps Style) */}
      <AnimatePresence mode="wait">
        {stage === 'brand' ? (
          <motion.div
            key="app-brand-splash"
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.06, y: -15 }}
            transition={{ duration: 0.4 }}
            className="flex-1 flex flex-col items-center justify-center text-center z-10 my-auto w-full max-w-md px-4 cursor-pointer"
            onClick={handleSkipBrandSplash}
          >
            {/* Center Logo with Pulse & Heartbeat Wave */}
            <div className="relative mb-6">
              {/* Outer Pulsing Aura */}
              <div className="absolute -inset-6 rounded-3xl bg-white/20 blur-2xl animate-pulse pointer-events-none" />
              
              {/* Logo Card */}
              <motion.div
                initial={{ scale: 0.75, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: 'spring', stiffness: 240, damping: 18 }}
                className="w-32 h-32 sm:w-36 sm:h-36 rounded-3xl bg-white shadow-2xl flex items-center justify-center p-3 text-sky-600 relative border-2 border-white/80"
              >
                <GramArogyaLogo size="3xl" />
              </motion.div>

              {/* Heartbeat pulse badge */}
              <div className="absolute -bottom-2 -right-2 bg-emerald-500 text-white rounded-full p-2.5 shadow-lg border-2 border-white flex items-center justify-center animate-bounce">
                <HeartPulse className="w-5 h-5 text-white" />
              </div>
            </div>

            {/* App Name: "curo" prominently displayed with high brand visibility */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15, duration: 0.4 }}
              className="flex flex-col items-center"
            >
              <h1 className="text-5xl sm:text-6xl font-black tracking-tight drop-shadow-md flex items-center justify-center">
                <span className="text-white drop-shadow-sm">cu</span>
                <span className="text-[#86efac] drop-shadow-sm">ro</span>
              </h1>

              {/* Localized Name Subtitle */}
              <div className="inline-flex items-center gap-1.5 mt-2 px-3.5 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold text-sky-50 border border-white/30">
                <span>{t.splashBrandTitle || 'క్యూరో • Rural Healthcare'}</span>
              </div>

              {/* Tagline */}
              <p className="text-sm sm:text-base text-white/95 font-medium max-w-xs mt-3 leading-snug drop-shadow-xs">
                {t.splashBrandTagline || t.splashMotto || 'Accessible Healthcare for Every Village'}
              </p>
            </motion.div>

            {/* Elegant Swiggy-style Pulsing Loading Dots */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.25 }}
              className="flex flex-col items-center gap-3 mt-10"
            >
              <div className="flex items-center justify-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-white animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-200 animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2.5 h-2.5 rounded-full bg-white animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span className="text-xs font-semibold text-white/85 tracking-wide">
                {t.splashBrandLoading || 'Starting curo...'}
              </span>
            </motion.div>
          </motion.div>
        ) : (
          /* STAGE 2: STEP-BY-STEP PERMISSION POP-UPS (Asked one after one) */
          <div className="w-full max-w-md z-20 my-auto">
            {/* Mini Branding Header during permission steps */}
            <div className="flex items-center justify-center gap-2.5 mb-3 text-center">
              <div className="w-8 h-8 rounded-xl bg-white shadow-md flex items-center justify-center p-1">
                <GramArogyaLogo size="sm" />
              </div>
              <span className="text-xl font-black text-white tracking-tight drop-shadow-xs">
                <span>cu</span><span className="text-emerald-200">ro</span>
              </span>
              <span className="text-xs text-white/80 font-medium ml-1">
                • {t.permissionSetupTitle || 'Permissions'}
              </span>
            </div>

            <AnimatePresence mode="wait" custom={direction}>
              {!isSummaryStep && currentConfig ? (
                /* Individual Permission Step Card (One after one) */
                <motion.div
                  key={`permission-step-${currentConfig.id}`}
                  custom={direction}
                  initial={{ opacity: 0, x: direction * 45, scale: 0.96 }}
                  animate={{ opacity: 1, x: 0, scale: 1 }}
                  exit={{ opacity: 0, x: -direction * 45, scale: 0.96 }}
                  transition={{ duration: 0.28, ease: 'easeOut' }}
                  className="bg-white rounded-3xl p-5 sm:p-6 text-slate-800 shadow-2xl border border-emerald-100"
                >
                  {/* Step Progress Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-black text-[#007ceb] uppercase tracking-wider">
                        {t.stepLabel || 'Step'} {currentStepIndex + 1} {t.ofLabel || 'of'} {totalSteps}
                      </span>
                    </div>

                    {/* 5 Step Indicator Dots */}
                    <div className="flex items-center gap-1.5">
                      {stepsConfig.map((step, idx) => {
                        const isDone = permissionsState[step.keyName] !== null;
                        const isCurrent = idx === currentStepIndex;
                        const isAllowed = permissionsState[step.keyName] === true;

                        return (
                          <div
                            key={step.id}
                            className={`h-2 rounded-full transition-all duration-300 ${
                              isCurrent 
                                ? 'w-6 bg-[#007ceb]' 
                                : isDone 
                                  ? isAllowed ? 'w-2 bg-[#00a651]' : 'w-2 bg-slate-300'
                                  : 'w-2 bg-slate-200'
                            }`}
                            title={step.badgeText}
                          />
                        );
                      })}
                    </div>
                  </div>

                  {/* Icon & Category Badge */}
                  <div className="flex items-center gap-3.5 mb-3.5">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border ${currentConfig.iconBoxClass} shadow-xs`}>
                      {currentConfig.renderIcon()}
                    </div>
                    <div>
                      <span className={`inline-block text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md border ${currentConfig.badgeClass}`}>
                        {currentConfig.badgeText}
                      </span>
                      <h2 className="text-base sm:text-lg font-black text-slate-900 leading-snug mt-0.5">
                        {currentConfig.heading}
                      </h2>
                    </div>
                  </div>

                  {/* Localized Plain Language Explanation */}
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-3.5">
                    {currentConfig.desc}
                  </p>

                  {/* Benefit Highlight Box */}
                  <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3 mb-4 flex items-start gap-2.5">
                    <Sparkles className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div className="text-[11px] font-semibold text-slate-700 leading-tight">
                      <span className="text-slate-900 font-extrabold">{currentConfig.title}: </span>
                      {currentConfig.benefit}
                    </div>
                  </div>

                  {/* Privacy Reassurance Note */}
                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-medium mb-4 px-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{t.privacyNote || 'Your privacy is protected. Used only for clinical triage & emergency care.'}</span>
                  </div>

                  {/* Action Buttons: Allow Access vs Don't Allow */}
                  <div className="space-y-2">
                    <button
                      id={`btn-allow-${currentConfig.id}`}
                      onClick={handleAllowCurrent}
                      className="w-full py-3 px-4 bg-gradient-to-r from-[#007ceb] to-[#00a651] hover:opacity-95 active:scale-[0.99] text-white font-black rounded-2xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
                    >
                      <Check className="w-4 h-4 text-white" />
                      <span>{t.allowWhileUsing || 'Allow Access'}</span>
                    </button>

                    <div className="flex items-center gap-2">
                      {currentStepIndex > 0 && (
                        <button
                          type="button"
                          onClick={handlePreviousStep}
                          className="py-2.5 px-3 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
                          title="Previous permission"
                        >
                          <ArrowLeft className="w-3.5 h-3.5" />
                          <span>Back</span>
                        </button>
                      )}

                      <button
                        id={`btn-skip-${currentConfig.id}`}
                        onClick={handleSkipCurrent}
                        className="flex-1 py-2.5 px-3 border border-slate-200 hover:bg-slate-100 text-slate-600 active:bg-slate-200 font-bold rounded-xl text-xs transition-colors text-center"
                      >
                        {t.dontAllow || "Don't Allow / Skip"}
                      </button>

                      <button
                        type="button"
                        onClick={handleAllowAllRemaining}
                        className="py-2.5 px-3 text-[#007ceb] hover:bg-sky-50 font-bold rounded-xl text-xs transition-colors shrink-0"
                        title="Allow all remaining permissions"
                      >
                        {t.allowAll || 'Allow All'}
                      </button>
                    </div>
                  </div>
                </motion.div>
              ) : (
                /* Summary Step Card: All 5 permissions configured */
                <motion.div
                  key="permission-summary"
                  initial={{ opacity: 0, scale: 0.92 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.92 }}
                  transition={{ duration: 0.3 }}
                  className="bg-white rounded-3xl p-5 sm:p-6 text-slate-800 shadow-2xl border border-emerald-100"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
                      <Check className="w-7 h-7 text-[#00a651]" />
                    </div>
                    <div>
                      <h2 className="text-base sm:text-lg font-black text-slate-900 leading-snug">
                        {t.permissionsSummaryTitle || 'All Permissions Configured'}
                      </h2>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {t.permissionsSummaryDesc || 'Your healthcare access settings have been saved.'}
                      </p>
                    </div>
                  </div>

                  {/* Status List of all 5 permissions in order: Notifications, Camera, Media, Mic, Location */}
                  <div className="space-y-2 my-4">
                    {/* 1. Notifications */}
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs font-semibold">
                      <div className="flex items-center gap-2 text-slate-700">
                        <BellRing className="w-4 h-4 text-amber-600" />
                        <span>{t.stepNotificationTitle || 'Notifications & Alarms'}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 ${
                        permissionsState.notificationsAllowed 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-slate-200 text-slate-600'
                      }`}>
                        {permissionsState.notificationsAllowed ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                        {permissionsState.notificationsAllowed 
                          ? (t.permissionGrantedStatus || 'Granted') 
                          : (t.permissionSkippedStatus || 'Skipped')}
                      </span>
                    </div>

                    {/* 2. Camera */}
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs font-semibold">
                      <div className="flex items-center gap-2 text-slate-700">
                        <Camera className="w-4 h-4 text-[#007ceb]" />
                        <span>{t.stepCameraTitle || 'Camera Access'}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 ${
                        permissionsState.cameraAllowed 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-slate-200 text-slate-600'
                      }`}>
                        {permissionsState.cameraAllowed ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                        {permissionsState.cameraAllowed 
                          ? (t.permissionGrantedStatus || 'Granted') 
                          : (t.permissionSkippedStatus || 'Skipped')}
                      </span>
                    </div>

                    {/* 3. Media & Storage */}
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs font-semibold">
                      <div className="flex items-center gap-2 text-slate-700">
                        <FolderHeart className="w-4 h-4 text-purple-600" />
                        <span>{t.stepMediaTitle || 'Media & Storage Access'}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 ${
                        permissionsState.mediaAllowed 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-slate-200 text-slate-600'
                      }`}>
                        {permissionsState.mediaAllowed ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                        {permissionsState.mediaAllowed 
                          ? (t.permissionGrantedStatus || 'Granted') 
                          : (t.permissionSkippedStatus || 'Skipped')}
                      </span>
                    </div>

                    {/* 4. Microphone / Voice */}
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs font-semibold">
                      <div className="flex items-center gap-2 text-slate-700">
                        <Mic className="w-4 h-4 text-[#00a651]" />
                        <span>{t.stepVoiceTitle || 'Microphone & Voice Access'}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 ${
                        (permissionsState.voiceAllowed || permissionsState.microphoneAllowed)
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-slate-200 text-slate-600'
                      }`}>
                        {(permissionsState.voiceAllowed || permissionsState.microphoneAllowed) ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                        {(permissionsState.voiceAllowed || permissionsState.microphoneAllowed)
                          ? (t.permissionGrantedStatus || 'Granted') 
                          : (t.permissionSkippedStatus || 'Skipped')}
                      </span>
                    </div>

                    {/* 5. Location */}
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs font-semibold">
                      <div className="flex items-center gap-2 text-slate-700">
                        <GoogleMapPin size={18} />
                        <span>{t.stepLocationTitle || 'Location Access'}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 ${
                        permissionsState.locationAllowed 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-slate-200 text-slate-600'
                      }`}>
                        {permissionsState.locationAllowed ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                        {permissionsState.locationAllowed 
                          ? (t.permissionGrantedStatus || 'Granted') 
                          : (t.permissionSkippedStatus || 'Skipped')}
                      </span>
                    </div>
                  </div>

                  <button
                    id="btn-continue-to-login"
                    onClick={handleFinalFinish}
                    className="w-full py-3.5 px-5 bg-gradient-to-r from-[#007ceb] to-[#00a651] hover:opacity-95 active:scale-[0.99] text-white font-black rounded-2xl text-sm shadow-md transition-all flex items-center justify-center gap-2 mt-4"
                  >
                    <span>{t.continueToLogin || 'Continue to Login ➔'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </AnimatePresence>

      {/* Footer Branding */}
      <div className="pt-2 text-center text-[10px] text-sky-100 font-medium z-10">
        curo • Accessible Rural Healthcare & Tele-Triage
      </div>
    </div>
  );
};
