import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Keyboard, Send, Volume2, Sparkles, AlertTriangle, ArrowRight, Stethoscope, RefreshCw, Activity, Droplets, Heart, Lock, Settings, CheckCircle2, X } from 'lucide-react';
import { ChatMessage, Language, UserProfile, TriageResult } from '../../types';
import { translations } from '../../i18n/translations';
import { voiceService, VoiceStatus } from '../../services/speech';
import { apiService } from '../../services/api';

interface HomeChatViewProps {
  currentUser: UserProfile | null;
  language: Language;
  onTriageComplete: (result: TriageResult) => void;
}

export const HomeChatView: React.FC<HomeChatViewProps> = ({
  currentUser,
  language,
  onTriageComplete,
}) => {
  const t = translations[language];

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState<VoiceStatus>('idle');
  const [voiceVolume, setVoiceVolume] = useState<number>(0);
  const [isPermissionDenied, setIsPermissionDenied] = useState(false);
  const [showKeyboard, setShowKeyboard] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Stop active voice session on unmount
  useEffect(() => {
    return () => {
      voiceService.stopListening();
      voiceService.stopSpeaking();
    };
  }, []);

  // Initialize welcome message when user changes or loads
  useEffect(() => {
    let welcomeText = '';
    const patientSalutation = currentUser?.name ? `${currentUser.name}! ` : '';
    if (language === 'te') {
      welcomeText = `నమస్కారం ${patientSalutation}నేను డాక్టర్ క్యూరో (Dr. Curo), మీ వాయిస్ అసిస్టెంట్. మీకు బీపీ, షుగర్, విరేచనాలు (డయేరియా) లేదా ఇతర ఎలాంటి సమస్య ఉన్నా మైక్రోఫోన్ నొక్కి మాట్లాడండి లేదా టైప్ చేయండి.`;
    } else if (language === 'hi') {
      welcomeText = `नमस्ते ${patientSalutation}मैं डॉ. क्यूरो (Dr. Curo), आपका वॉइस असिस्टेंट हूँ। आपको बीपी, शुगर, दस्त (डायरिया) या कोई अन्य समस्या हो तो माइक्रोफ़ोन दबाकर बोलें या लिखें।`;
    } else {
      welcomeText = `Hello, I'm Dr. Curo, your voice assistant. ${patientSalutation ? `Welcome ${currentUser?.name}! ` : ''}If you have concerns about BP, Sugar/Diabetes, Diarrhoea, or other symptoms, tap the microphone to speak or type below.`;
    }

    const initialMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'assistant',
      text: welcomeText,
      language,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages([initialMsg]);
  }, [language, currentUser]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing]);

  const handleSendMessage = async (textToSend: string) => {
    const text = textToSend.trim();
    if (!text || isProcessing) return;

    setInputText('');
    setVoiceError(null);

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      language,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setIsProcessing(true);

    try {
      const reply = await apiService.sendChatMessage(text, newHistory, language, currentUser);

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: reply,
        language,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      console.error('Chat error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRequestMicrophone = async () => {
    setVoiceError(null);
    setVoiceStatus('requesting');
    const res = await voiceService.requestMicrophonePermission();
    if (res.granted) {
      setIsPermissionDenied(false);
      setVoiceError(null);
      // Immediately start listening
      toggleListening();
    } else {
      setIsPermissionDenied(true);
      setVoiceError(res.error || t.voicePermissionDenied);
      setVoiceStatus('idle');
    }
  };

  const toggleListening = async () => {
    setVoiceError(null);
    setIsPermissionDenied(false);

    if (isListening) {
      setVoiceStatus('transcribing');
      await voiceService.stopListening();
      setIsListening(false);
    } else {
      setVoiceStatus('requesting');
      const started = await voiceService.startListening(
        language,
        (transcript, isFinal) => {
          if (isFinal) {
            if (transcript.trim()) {
              handleSendMessage(transcript.trim());
            }
            setIsListening(false);
            setVoiceStatus('idle');
            setVoiceVolume(0);
          } else {
            setInputText(transcript);
          }
        },
        (errorMsg, denied) => {
          setIsListening(false);
          setVoiceStatus('idle');
          setVoiceVolume(0);
          if (denied) {
            setIsPermissionDenied(true);
            setVoiceError(t.voicePermissionDenied || errorMsg);
          } else {
            setVoiceError(errorMsg);
          }
        },
        () => {
          setIsListening(false);
          setVoiceStatus('idle');
          setVoiceVolume(0);
        },
        (vol) => {
          setVoiceVolume(vol);
        },
        (status) => {
          setVoiceStatus(status);
          if (status === 'listening') {
            setIsListening(true);
            setIsPermissionDenied(false);
            setVoiceError(null);
          } else if (status === 'idle') {
            setIsListening(false);
          }
        }
      );

      if (!started) {
        setVoiceStatus('idle');
        setIsListening(false);
      }
    }
  };

  const handleGenerateReport = async () => {
    if (generatingReport) return;
    setGeneratingReport(true);

    try {
      const result = await apiService.analyzeTriage(messages, language, currentUser);
      onTriageComplete(result);
    } catch (e) {
      console.error('Error generating report', e);
    } finally {
      setGeneratingReport(false);
    }
  };

  const handleQuickSymptom = (symptomText: string) => {
    handleSendMessage(symptomText);
  };

  const handleSpeechSpeak = (text: string) => {
    voiceService.speak(text, language);
  };

  return (
    <div className="flex flex-col h-[calc(100dvh-125px)] w-full max-w-4xl mx-auto px-3 sm:px-5 py-1.5 min-h-0">
      {/* Top Header / Triage Banner - Compact, streamlined to maximize chat block */}
      <div className="bg-gradient-to-r from-[#007ceb] via-[#0284c7] to-[#00a651] rounded-2xl py-2 px-3 sm:px-4 text-white shadow-xs mb-1.5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center shrink-0">
            <Stethoscope className="w-4 h-4 text-white" />
          </div>
          <div>
            <h2 className="text-xs sm:text-sm font-black leading-tight">{t.voiceAssistantTitle}</h2>
            <p className="text-[10px] sm:text-[11px] text-sky-50 font-medium leading-tight line-clamp-1">
              {messages.length > 2 ? `${messages.length} responses evaluated` : t.voiceAssistantDesc}
            </p>
          </div>
        </div>

        {/* Generate Report Button when user has sent at least one symptom */}
        {messages.length >= 2 && (
          <button
            id="btn-generate-report-top"
            type="button"
            onClick={handleGenerateReport}
            disabled={generatingReport}
            className="px-2.5 sm:px-3 py-1.5 bg-[#00a651] hover:bg-emerald-600 active:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-sm flex items-center gap-1 shrink-0 transition-transform active:scale-95 animate-pulse cursor-pointer"
          >
            {generatingReport ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-amber-200" />
            )}
            <span>{language === 'te' ? 'నివేదిక' : language === 'hi' ? 'रिपोर्ट' : 'Report'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Quick Common Rural Symptoms Chips - Includes BP, Sugar, Diarrhoea (#6) */}
      <div className="mb-1.5">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider shrink-0 mr-1">
            {t.quickSymptoms}
          </span>
          
          {/* BP Option (#6) */}
          <button
            id="btn-quick-bp"
            type="button"
            onClick={() => handleQuickSymptom(language === 'te' ? 'BP (రక్తపోటు)' : language === 'hi' ? 'BP (रक्तचाप)' : 'BP')}
            className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 rounded-full font-bold shrink-0 shadow-2xs transition-all flex items-center gap-1 cursor-pointer"
          >
            <Heart className="w-3.5 h-3.5 text-[#e51b24]" />
            <span>{t.symptomBp}</span>
          </button>

          {/* Sugar Option (#6) */}
          <button
            id="btn-quick-sugar"
            type="button"
            onClick={() => handleQuickSymptom(language === 'te' ? 'షుగర్ (Sugar)' : language === 'hi' ? 'शुगर (Sugar)' : 'Sugar')}
            className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 rounded-full font-bold shrink-0 shadow-2xs transition-all flex items-center gap-1 cursor-pointer"
          >
            <Activity className="w-3.5 h-3.5 text-amber-600" />
            <span>{t.symptomSugar}</span>
          </button>

          {/* Diarrhoea Option (#6) */}
          <button
            id="btn-quick-diarrhoea"
            type="button"
            onClick={() => handleQuickSymptom(language === 'te' ? 'విరేచనాలు (Diarrhoea)' : language === 'hi' ? 'दस्त (Diarrhoea)' : 'Diarrhoea')}
            className="px-3 py-1.5 bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 rounded-full font-bold shrink-0 shadow-2xs transition-all flex items-center gap-1 cursor-pointer"
          >
            <Droplets className="w-3.5 h-3.5 text-[#007ceb]" />
            <span>{t.symptomDiarrhoea}</span>
          </button>

          {/* Fever */}
          <button
            type="button"
            onClick={() => handleQuickSymptom(language === 'te' ? 'జ్వరం (Fever)' : language === 'hi' ? 'बुखार (Fever)' : 'Fever')}
            className="px-2.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-full font-semibold shrink-0 shadow-2xs transition-colors cursor-pointer"
          >
            {t.symptomFever}
          </button>

          {/* Cough */}
          <button
            type="button"
            onClick={() => handleQuickSymptom(language === 'te' ? 'దగ్గు (Cough)' : language === 'hi' ? 'खांसी (Cough)' : 'Cough')}
            className="px-2.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-full font-semibold shrink-0 shadow-2xs transition-colors cursor-pointer"
          >
            {t.symptomCough}
          </button>

          {/* Stomach */}
          <button
            type="button"
            onClick={() => handleQuickSymptom(language === 'te' ? 'కడుపు నొప్పి (Stomach Ache)' : language === 'hi' ? 'पेट दर्द (Stomach Ache)' : 'Stomach Ache')}
            className="px-2.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-full font-semibold shrink-0 shadow-2xs transition-colors cursor-pointer"
          >
            {t.symptomStomach}
          </button>
        </div>
      </div>

      {/* Voice Error & Permission Troubleshooting Card */}
      {voiceError && (
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          className={`mb-2 rounded-2xl border shadow-sm p-3.5 transition-all ${
            isPermissionDenied
              ? 'bg-gradient-to-br from-amber-50 to-rose-50 border-amber-300/80 text-slate-800'
              : 'bg-rose-50 border-rose-200 text-rose-850'
          }`}
        >
          {isPermissionDenied ? (
            <div className="space-y-2.5">
              {/* Header */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-700 flex items-center justify-center shrink-0">
                    <Lock className="w-4 h-4 text-amber-600" />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-black text-slate-900 leading-tight">
                      {t.micHelpTitle || 'Microphone Permission Guide'}
                    </h4>
                    <p className="text-[11px] text-slate-600 font-medium leading-tight">
                      {t.micHelpDesc || 'Microphone access is needed to speak directly with Dr. Curo voice assistant.'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setVoiceError(null);
                    setIsPermissionDenied(false);
                  }}
                  className="text-slate-400 hover:text-slate-700 p-1 rounded-lg cursor-pointer"
                  aria-label="Dismiss guide"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* 3 Step Visual Guide */}
              <div className="bg-white/80 backdrop-blur-xs rounded-xl p-2.5 border border-amber-200/70 space-y-1.5 text-[11px] font-medium text-slate-700">
                <div className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">1</span>
                  <span>{t.micStep1 || 'Click the 🔒 Lock or ⚙️ Settings icon in your browser address bar at the top.'}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">2</span>
                  <span>{t.micStep2 || 'Find "Microphone" and switch it to "Allow" / toggle ON.'}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">3</span>
                  <span>{t.micStep3 || 'Click "Try Microphone Again" or reload the page.'}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2 pt-0.5">
                <button
                  id="btn-retry-mic-permission"
                  type="button"
                  onClick={handleRequestMicrophone}
                  className="flex-1 min-w-[140px] py-2 px-3 bg-gradient-to-r from-[#007ceb] to-[#00a651] hover:opacity-95 text-white font-black rounded-xl text-xs shadow-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
                >
                  <Mic className="w-3.5 h-3.5" />
                  <span>{t.micTryAgainBtn || 'Enable & Try Microphone Again'}</span>
                </button>

                <button
                  id="btn-fallback-keyboard"
                  type="button"
                  onClick={() => {
                    setShowKeyboard(true);
                    setVoiceError(null);
                    setIsPermissionDenied(false);
                  }}
                  className="py-2 px-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-bold rounded-xl text-xs shadow-2xs flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Keyboard className="w-3.5 h-3.5 text-[#007ceb]" />
                  <span>{t.micUseKeyboardBtn || 'Type with Keyboard Instead'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between gap-2 text-xs font-semibold">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-[#e51b24]" />
                <span>{voiceError}</span>
              </div>
              <button
                type="button"
                onClick={() => setVoiceError(null)}
                className="text-slate-400 hover:text-slate-700 px-1.5 py-0.5 rounded-lg cursor-pointer font-bold"
                aria-label="Dismiss error"
              >
                ✕
              </button>
            </div>
          )}
        </motion.div>
      )}

      {/* Chat Messages Scroll Container - Increased Size, Spaciousness & Readability */}
      <div 
        id="chat-messages-container"
        className="flex-1 min-h-0 overflow-y-auto space-y-3.5 sm:space-y-4 p-3.5 sm:p-5 bg-white rounded-3xl border border-slate-200/90 shadow-xs"
      >
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex items-start gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-8.5 h-8.5 sm:w-9.5 sm:h-9.5 rounded-2xl bg-gradient-to-br from-[#007ceb] to-[#00a651] flex items-center justify-center text-white font-black text-xs shrink-0 shadow-xs ring-2 ring-sky-100" title="Dr. Curo AI Assistant">
                  <Stethoscope className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
              )}

              <div
                className={`max-w-[88%] sm:max-w-[82%] rounded-3xl p-3.5 sm:p-4 shadow-xs ${
                  isUser
                    ? 'bg-[#007ceb] text-white rounded-br-xs'
                    : 'bg-slate-50 border border-slate-200 text-slate-800 rounded-tl-xs'
                }`}
              >
                <div className="text-sm sm:text-base font-medium leading-relaxed whitespace-pre-line">
                  {msg.text}
                </div>

                <div className="flex items-center justify-between gap-2 mt-2 pt-1.5 border-t border-black/5 text-[10.5px] sm:text-[11px] opacity-80">
                  <span>{msg.timestamp}</span>
                  {!isUser && (
                    <button
                      type="button"
                      onClick={() => handleSpeechSpeak(msg.text)}
                      className="px-2 py-0.5 rounded-md hover:bg-slate-200 text-slate-700 transition-colors flex items-center gap-1 font-bold cursor-pointer"
                      title="Read aloud"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>{language === 'te' ? 'వినండి' : language === 'hi' ? 'सुनें' : 'Listen'}</span>
                    </button>
                  )}
                </div>
              </div>

              {isUser && (
                <div className="w-8.5 h-8.5 sm:w-9.5 sm:h-9.5 rounded-2xl bg-[#00a651] flex items-center justify-center text-white font-black text-xs sm:text-sm shrink-0 shadow-xs">
                  {currentUser?.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
                </div>
              )}
            </motion.div>
          );
        })}

        {isProcessing && (
          <div className="flex items-center gap-2 text-slate-600 text-xs sm:text-sm font-semibold p-2 bg-sky-50 rounded-2xl border border-sky-100 w-fit">
            <div className="w-6 h-6 rounded-lg bg-sky-200 flex items-center justify-center animate-spin">
              <RefreshCw className="w-3.5 h-3.5 text-[#007ceb]" />
            </div>
            <span>{t.thinkingAi}</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Action to Generate Summary Report */}
      {messages.length >= 2 && (
        <div className="mt-1.5 text-center">
          <button
            id="btn-generate-report-bottom"
            type="button"
            onClick={handleGenerateReport}
            disabled={generatingReport}
            className="w-full py-2 bg-gradient-to-r from-[#007ceb] to-[#00a651] hover:opacity-95 active:scale-[0.99] text-white font-black rounded-xl text-xs sm:text-sm shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {generatingReport ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-amber-200" />
            )}
            <span>{t.generateReportBtn}</span>
          </button>
        </div>
      )}

      {/* Voice Assistant Controls - Decreased in size to maximize chat space */}
      <div 
        id="voice-assistant-section"
        className="mt-1.5 bg-white px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-2xl border border-slate-200 shadow-xs"
      >
        <AnimatePresence mode="wait">
          {showKeyboard ? (
            /* Keyboard Mode with Compact Voice Assistant Icon */
            <motion.form
              key="keyboard-mode"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(inputText);
              }}
              className="flex items-center gap-2"
            >
              {/* Compact Voice Assistant Button */}
              <motion.button
                id="btn-voice-mic-input"
                type="button"
                whileTap={{ scale: 0.92 }}
                onClick={toggleListening}
                className={`w-9.5 h-9.5 rounded-xl flex items-center justify-center transition-all shrink-0 cursor-pointer ${
                  isListening
                    ? 'bg-[#e51b24] text-white ring-2 ring-rose-200 animate-pulse'
                    : 'bg-sky-50 text-[#007ceb] hover:bg-sky-100 border border-sky-200 shadow-2xs'
                }`}
                title={isListening ? t.stopVoiceBtn : t.startVoiceBtn}
              >
                {isListening ? (
                  <MicOff className="w-4 h-4 animate-bounce" />
                ) : (
                  <Mic className="w-4 h-4" />
                )}
              </motion.button>

              <input
                id="input-chat-text"
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={t.typeMessagePlaceholder}
                className="flex-1 min-w-0 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#007ceb] focus:bg-white"
              />

              <button
                id="btn-send-message"
                type="submit"
                disabled={!inputText.trim() || isProcessing}
                className="p-2 sm:px-3 sm:py-2 bg-[#007ceb] hover:bg-sky-700 disabled:opacity-40 text-white rounded-xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer text-xs font-bold"
              >
                <Send className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Send</span>
              </button>

              <button
                id="btn-switch-to-voice"
                type="button"
                onClick={() => setShowKeyboard(false)}
                className="p-2 text-slate-500 hover:text-[#007ceb] hover:bg-sky-50 rounded-xl transition-colors shrink-0 cursor-pointer"
                title={t.keyboardToggleVoice}
              >
                <Mic className="w-4 h-4" />
              </button>
            </motion.form>
          ) : (
            /* Streamlined Compact Voice Assistant Bar (Decreased size) */
            <motion.div
              key="voice-mode"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="flex items-center justify-between gap-2"
            >
              {/* Voice Status Indicator with Audio Waveform */}
              <div className="flex items-center gap-2.5 min-w-0 flex-1">
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                    isListening
                      ? 'bg-rose-100 text-[#e51b24] ring-2 ring-rose-300'
                      : voiceStatus === 'transcribing'
                      ? 'bg-amber-100 text-amber-600'
                      : voiceStatus === 'requesting'
                      ? 'bg-sky-100 text-[#007ceb]'
                      : 'bg-sky-50 text-[#007ceb]'
                  }`}
                >
                  {isListening ? (
                    <Mic className="w-4 h-4 text-[#e51b24] animate-pulse" />
                  ) : voiceStatus === 'transcribing' || voiceStatus === 'requesting' ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Mic className="w-4 h-4 text-[#007ceb]" />
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="text-xs font-bold text-slate-800 leading-tight flex items-center gap-2">
                    {isListening ? (
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-[#e51b24] font-extrabold flex items-center gap-1.5 shrink-0">
                          <span className="w-2 h-2 rounded-full bg-[#e51b24] animate-ping" />
                          {t.listeningPrompt}
                        </span>
                        {/* Live Audio Level Waveform */}
                        <div className="flex items-center gap-0.5 sm:gap-1 h-4 shrink-0">
                          <motion.span
                            className="w-1 bg-[#e51b24] rounded-full"
                            animate={{ height: voiceVolume > 10 ? 14 : 5 }}
                            transition={{ duration: 0.1 }}
                          />
                          <motion.span
                            className="w-1 bg-[#e51b24] rounded-full"
                            animate={{ height: voiceVolume > 30 ? 18 : 7 }}
                            transition={{ duration: 0.1 }}
                          />
                          <motion.span
                            className="w-1 bg-[#e51b24] rounded-full"
                            animate={{ height: voiceVolume > 50 ? 20 : 9 }}
                            transition={{ duration: 0.1 }}
                          />
                          <motion.span
                            className="w-1 bg-[#e51b24] rounded-full"
                            animate={{ height: voiceVolume > 30 ? 16 : 7 }}
                            transition={{ duration: 0.1 }}
                          />
                          <motion.span
                            className="w-1 bg-[#e51b24] rounded-full"
                            animate={{ height: voiceVolume > 10 ? 12 : 5 }}
                            transition={{ duration: 0.1 }}
                          />
                        </div>
                      </div>
                    ) : voiceStatus === 'transcribing' ? (
                      <span className="text-amber-700 font-bold flex items-center gap-1.5 truncate">
                        <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse shrink-0" />
                        {t.voiceTranscribing}
                      </span>
                    ) : voiceStatus === 'requesting' ? (
                      <span className="text-[#007ceb] font-bold">Connecting microphone...</span>
                    ) : (
                      <span>{t.voiceAssistantTitle}</span>
                    )}
                  </div>
                  <div className="text-[10px] sm:text-[11px] text-slate-500 font-medium truncate mt-0.5">
                    {isListening ? (
                      inputText ? (
                        <span className="text-[#007ceb] italic font-semibold">"{inputText}"</span>
                      ) : (
                        'Speak symptoms in Telugu, Hindi, or English...'
                      )
                    ) : voiceStatus === 'transcribing' ? (
                      'Processing voice...'
                    ) : (
                      t.startVoiceBtn
                    )}
                  </div>
                </div>
              </div>

              {/* Decreased Voice Assistant Mic Button (Compact 44px) */}
              <div className="flex items-center gap-2 shrink-0">
                <motion.button
                  id="btn-voice-mic-main"
                  type="button"
                  whileTap={{ scale: 0.94 }}
                  onClick={toggleListening}
                  disabled={voiceStatus === 'transcribing' || voiceStatus === 'requesting'}
                  className={`relative w-11 h-11 rounded-2xl flex items-center justify-center shadow-sm transition-all cursor-pointer ${
                    isListening
                      ? 'bg-[#e51b24] text-white ring-4 ring-rose-200'
                      : voiceStatus === 'transcribing' || voiceStatus === 'requesting'
                      ? 'bg-amber-500 text-white opacity-80'
                      : 'bg-gradient-to-tr from-[#007ceb] to-[#00a651] text-white hover:opacity-95'
                  }`}
                  aria-label={isListening ? t.stopVoiceBtn : t.startVoiceBtn}
                  title={isListening ? t.stopVoiceBtn : t.startVoiceBtn}
                >
                  {isListening ? (
                    <MicOff className="w-5 h-5 animate-bounce" />
                  ) : voiceStatus === 'transcribing' || voiceStatus === 'requesting' ? (
                    <RefreshCw className="w-5 h-5 animate-spin" />
                  ) : (
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" fill="currentColor" fillOpacity="0.2" />
                      <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
                      <line x1="12" x2="12" y1="19" y2="22" />
                      <line x1="8" x2="16" y1="22" y2="22" />
                    </svg>
                  )}
                  {isListening && (
                    <span className="absolute -inset-1 rounded-2xl border-2 border-rose-400 animate-ping pointer-events-none" />
                  )}
                </motion.button>

                {/* Keyboard Mode Toggle Button */}
                <button
                  id="btn-toggle-keyboard"
                  type="button"
                  onClick={() => setShowKeyboard(true)}
                  className="text-xs font-bold text-[#007ceb] hover:text-sky-800 flex items-center gap-1.5 px-2.5 sm:px-3 py-2 rounded-xl bg-sky-50 hover:bg-sky-100 transition-colors cursor-pointer shrink-0"
                  title={t.keyboardToggleShow}
                >
                  <Keyboard className="w-3.5 h-3.5" />
                  <span className="hidden xs:inline">{t.keyboardToggleShow}</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
