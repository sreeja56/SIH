import { UserProfile, TriageResult, ChatMessage, Doctor, Appointment, MedicalDocument, Language, AppPermissions, UserFeedback } from '../types';
import { mockDoctors, initialSampleDocuments } from '../data/mockData';
import { firestoreService } from './firestoreService';

const USERS_STORAGE_KEY = 'gramarogya_users_v1';
const CURRENT_USER_KEY = 'gramarogya_current_user_v1';
const BOOKINGS_STORAGE_KEY = 'gramarogya_bookings_v1';
const DOCUMENTS_STORAGE_KEY = 'gramarogya_documents_v1';
const PERMISSIONS_STORAGE_KEY = 'gramarogya_permissions_v1';
const DOCTORS_SLOTS_STORAGE_KEY = 'gramarogya_doctors_slots_v3';
const FEEDBACK_STORAGE_KEY = 'gramarogya_feedback_v1';

// Seed default demo user for evaluation
const defaultDemoUser: UserProfile = {
  username: 'ravi_kumar',
  pin: '1234',
  phone: '9876543210',
  name: 'Ravi Kumar (రవి కుమార్)',
  age: 36,
  gender: 'male',
  language: 'en',
  village: 'Rampur Village',
  district: 'Medak',
  bloodGroup: 'O+',
  emergencyContact: '+91 98480 99887',
  isOtpVerified: true,
  otpVerifiedAt: new Date().toISOString(),
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

export const apiService = {
  // Initial sync from Firestore on app load
  async syncFromFirestore(): Promise<void> {
    try {
      const [remoteUsers, remoteAppointments, remoteDocs, remoteFeedback] = await Promise.all([
        firestoreService.fetchUsers(),
        firestoreService.fetchAppointments(),
        firestoreService.fetchDocuments(),
        firestoreService.fetchFeedback(),
      ]);

      if (remoteUsers && remoteUsers.length > 0) {
        const localUsers = this.getUsers();
        const mergedUsers = [...localUsers];
        for (const ru of remoteUsers) {
          const idx = mergedUsers.findIndex(u => (u.phone && ru.phone && u.phone.replace(/\D/g, '') === ru.phone.replace(/\D/g, '')) || (u.username && u.username === ru.username));
          if (idx >= 0) {
            mergedUsers[idx] = { ...mergedUsers[idx], ...ru };
          } else {
            mergedUsers.push(ru);
          }
        }
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(mergedUsers));
      }

      if (remoteAppointments && remoteAppointments.length > 0) {
        const localAppts = this.getBookings();
        const mergedAppts = [...localAppts];
        for (const ra of remoteAppointments) {
          const idx = mergedAppts.findIndex(a => a.id === ra.id || (a.uniqueId && a.uniqueId === ra.uniqueId));
          if (idx >= 0) {
            mergedAppts[idx] = { ...mergedAppts[idx], ...ra };
          } else {
            mergedAppts.push(ra);
          }
        }
        localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(mergedAppts));
      }

      if (remoteDocs && remoteDocs.length > 0) {
        const localDocs = this.getDocuments();
        const mergedDocs = [...localDocs];
        for (const rd of remoteDocs) {
          const idx = mergedDocs.findIndex(d => d.id === rd.id);
          if (idx >= 0) {
            mergedDocs[idx] = { ...mergedDocs[idx], ...rd };
          } else {
            mergedDocs.push(rd);
          }
        }
        localStorage.setItem(DOCUMENTS_STORAGE_KEY, JSON.stringify(mergedDocs));
      }

      if (remoteFeedback && remoteFeedback.length > 0) {
        const localFb = this.getFeedback();
        const mergedFb = [...localFb];
        for (const rf of remoteFeedback) {
          if (!mergedFb.some(f => f.id === rf.id)) {
            mergedFb.push(rf);
          }
        }
        localStorage.setItem(FEEDBACK_STORAGE_KEY, JSON.stringify(mergedFb));
      }
    } catch (e) {
      console.warn('Firestore initial sync notice:', e);
    }
  },

  // --- Auth & Users ---
  getUsers(): UserProfile[] {
    try {
      const data = localStorage.getItem(USERS_STORAGE_KEY);
      if (!data) {
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify([defaultDemoUser]));
        return [defaultDemoUser];
      }
      const parsed = JSON.parse(data);
      if (!Array.isArray(parsed) || parsed.length === 0) {
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify([defaultDemoUser]));
        return [defaultDemoUser];
      }
      return parsed;
    } catch {
      return [defaultDemoUser];
    }
  },

  saveUser(user: UserProfile): void {
    const cleanUserUsername = (user.username || '').trim().toLowerCase();
    const cleanUserPhone = (user.phone || '').trim().replace(/\D/g, '');

    const users = this.getUsers().filter(u => {
      const existingUname = (u.username || '').trim().toLowerCase();
      const existingPhone = (u.phone || '').trim().replace(/\D/g, '');
      return existingUname !== cleanUserUsername && existingPhone !== cleanUserPhone;
    });

    const updatedUser: UserProfile = {
      ...user,
      isOtpVerified: user.isOtpVerified ?? true,
      updatedAt: new Date().toISOString(),
    };

    users.push(updatedUser);
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    this.setCurrentUser(updatedUser);

    // Asynchronously persist to Firestore cloud storage
    firestoreService.saveUser(updatedUser).catch(console.warn);
  },

  findUser(identifier: string): UserProfile | null {
    const clean = identifier.trim();
    const cleanLower = clean.toLowerCase();
    const cleanPhoneDigits = clean.replace(/\D/g, '');

    const users = this.getUsers();
    return users.find(u => {
      const uName = (u.username || '').trim().toLowerCase();
      const uPhone = (u.phone || '').trim().replace(/\D/g, '');

      if (uName && uName === cleanLower) return true;
      if (cleanPhoneDigits.length >= 10 && uPhone && (uPhone === cleanPhoneDigits || uPhone.endsWith(cleanPhoneDigits))) return true;
      if (u.username === clean || u.phone === clean) return true;
      return false;
    }) || null;
  },

  getCurrentUser(): UserProfile | null {
    try {
      const data = localStorage.getItem(CURRENT_USER_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  setCurrentUser(user: UserProfile | null): void {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  },

  // --- Permissions ---
  getPermissions(): AppPermissions {
    try {
      const data = localStorage.getItem(PERMISSIONS_STORAGE_KEY);
      return data
        ? JSON.parse(data)
        : {
            locationAllowed: null,
            cameraAllowed: null,
            mediaAllowed: null,
            voiceAllowed: null,
            microphoneAllowed: null,
            notificationsAllowed: null,
          };
    } catch {
      return {
        locationAllowed: null,
        cameraAllowed: null,
        mediaAllowed: null,
        voiceAllowed: null,
        microphoneAllowed: null,
        notificationsAllowed: null,
      };
    }
  },

  savePermissions(permissions: AppPermissions): void {
    localStorage.setItem(PERMISSIONS_STORAGE_KEY, JSON.stringify(permissions));
  },

  // --- AI Chatbot ---
  async sendChatMessage(
    message: string,
    history: ChatMessage[],
    language: Language,
    userProfile: UserProfile | null
  ): Promise<string> {
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          conversationHistory: history,
          language,
          userProfile,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      const data = await response.json();
      return data.text || 'I have recorded your symptoms. Please visit the nearest PHC if discomfort increases.';
    } catch (e) {
      console.warn('API Chat fetch fallback:', e);
      if (language === 'te') {
        return 'మీ లక్షణాలను నమోదు చేసాము. దయచేసి పుష్కలంగా నీరు తాగి విశ్రాంతి తీసుకోండి. సమస్య తీవ్రమైతే వెంటనే సమీప PHCకి వెళ్ళండి లేదా 108 కి కాల్ చేయండి.';
      } else if (language === 'hi') {
        return 'आपके लक्षणों को नोट कर लिया गया है। कृपया आराम करें और पर्याप्त पानी पिएं। यदि तकलीफ अधिक हो तो तुरंत PHC जाएं या 108 पर कॉल करें।';
      }
      return 'I have recorded your symptoms. Please rest, stay well-hydrated, and consult a doctor at the nearest PHC if symptoms persist.';
    }
  },

  // --- Direct Audio Transcription via Gemini API ---
  async transcribeAudio(audioBlob: Blob, language: Language): Promise<string> {
    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onloadend = () => {
          const result = reader.result as string;
          resolve(result);
        };
        reader.onerror = reject;
      });
      reader.readAsDataURL(audioBlob);
      const dataUrl = await base64Promise;

      const response = await fetch('/api/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioData: dataUrl,
          mimeType: audioBlob.type || 'audio/webm',
          language,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      return (data.text || '').trim();
    } catch (err) {
      console.warn('API Transcribe fallback warning:', err);
      return '';
    }
  },

  // --- AI Clinical Triage Analysis ---
  async analyzeTriage(
    messages: ChatMessage[],
    language: Language,
    userProfile: UserProfile | null
  ): Promise<TriageResult> {
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages,
          language,
          userProfile,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      const data = await response.json();
      if (data.success && data.result) {
        const resultObj: TriageResult = {
          id: `triage-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          patientName: userProfile?.name || 'Patient',
          patientAge: userProfile?.age || 30,
          patientGender: userProfile?.gender || 'other',
          ...data.result,
        };
        // Persist diagnosis result to Firestore
        firestoreService.saveTriageResult(resultObj).catch(console.warn);
        return resultObj;
      }
      throw new Error('Invalid format');
    } catch (e) {
      console.warn('API Analyze fallback:', e);
      const fallbackResult: TriageResult = {
        id: `triage-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        severity: 'moderate',
        severityLabel: language === 'te' ? 'మితమైన సంరక్షణ (MODERATE)' : language === 'hi' ? 'मध्यम स्तर (MODERATE)' : 'MODERATE Care Required',
        patientName: userProfile?.name || 'Patient',
        patientAge: userProfile?.age || 30,
        patientGender: userProfile?.gender || 'male',
        chiefComplaint: language === 'te' ? 'జ్వరం మరియు నీరసం' : language === 'hi' ? 'बुखार और शारीरिक कमजोरी' : 'Fever and Physical Discomfort',
        symptomsList: ['Fever', 'Body Pain', 'Mild Headache'],
        durationDays: '2-3 days',
        painLevel: 5,
        summary: language === 'te' 
          ? 'లక్షణాలు సాధారణ వైరల్ జ్వరాన్ని సూచిస్తున్నాయి. 24 గంటల్లో డాక్టర్‌ని సంప్రదించి పరీక్ష చేయించుకోండి.'
          : language === 'hi'
          ? 'लक्षण सामान्य मौसमी बुखार के अनुकूल हैं। 24 घंटे में डॉक्टर से परामर्श लें।'
          : 'Symptoms are consistent with a moderate seasonal viral condition. A clinical checkup at the PHC is recommended within 24 hours.',
        possibleConditions: [
          {
            name: 'Viral Pyrexia / Seasonal Infection',
            description: 'Common seasonal viral elevation in temperature.',
            level: 'Probable Match'
          }
        ],
        recommendedAction: 'Book an appointment at your local Primary Health Centre (PHC) for doctor consultation.',
        homeCareTips: [
          'Drink warm boiled water throughout the day.',
          'Take complete bed rest in a well-ventilated room.',
          'Eat freshly prepared light porridge or soup.'
        ],
        warningSigns: [
          'High fever above 102.5°F',
          'Severe breathing difficulty or chest tightness',
          'Persistent vomiting or inability to keep liquids down'
        ],
        needImmediateEmergency: false
      };
      firestoreService.saveTriageResult(fallbackResult).catch(console.warn);
      return fallbackResult;
    }
  },

  // --- Doctors & Live Slot Management ---
  getDoctors(): Doctor[] {
    try {
      const stored = localStorage.getItem(DOCTORS_SLOTS_STORAGE_KEY);
      if (stored) {
        const parsed: Doctor[] = JSON.parse(stored);
        return parsed.map(d => ({ ...d, fee: 0 }));
      }
      const initial = mockDoctors.map(d => ({ ...d, fee: 0 }));
      localStorage.setItem(DOCTORS_SLOTS_STORAGE_KEY, JSON.stringify(initial));
      return initial;
    } catch {
      return mockDoctors.map(d => ({ ...d, fee: 0 }));
    }
  },

  saveDoctors(doctors: Doctor[]): void {
    const freeDoctors = doctors.map(d => ({ ...d, fee: 0 }));
    localStorage.setItem(DOCTORS_SLOTS_STORAGE_KEY, JSON.stringify(freeDoctors));
  },

  getBookings(): Appointment[] {
    try {
      const data = localStorage.getItem(BOOKINGS_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  createBooking(bookingData: Omit<Appointment, 'id' | 'uniqueId' | 'tokenNumber' | 'createdAt' | 'status'>): {
    success: boolean;
    appointment?: Appointment;
    errorMessage?: string;
  } {
    const doctors = this.getDoctors();
    const doctor = doctors.find(d => d.id === bookingData.doctorId);

    if (!doctor) {
      return { success: false, errorMessage: 'Doctor not found' };
    }

    const slot = doctor.timeSlots.find(s => s.time === bookingData.timeSlot);
    if (!slot || slot.availableSlots <= 0 || !slot.available) {
      return {
        success: false,
        errorMessage: 'NO_SLOTS_AVAILABLE',
      };
    }

    // Decrement slot count
    slot.availableSlots = Math.max(0, slot.availableSlots - 1);
    if (slot.availableSlots === 0) {
      slot.available = false;
    }

    this.saveDoctors(doctors);

    const existing = this.getBookings();
    const uniqueId = `GA-APPT-${Math.floor(10000 + Math.random() * 90000)}`;
    const tokenNumber = Math.floor(1 + Math.random() * 25);

    const newAppointment: Appointment = {
      id: `appt-${Date.now()}`,
      uniqueId,
      tokenNumber,
      status: 'confirmed',
      alarmSet: true, // Default 30-min alarm enabled
      alarmMinutesBefore: 30,
      createdAt: new Date().toISOString(),
      ...bookingData,
    };

    existing.unshift(newAppointment);
    localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(existing));

    // Save appointment to Firestore cloud
    firestoreService.saveAppointment(newAppointment).catch(console.warn);

    return {
      success: true,
      appointment: newAppointment,
    };
  },

  toggleAppointmentAlarm(id: string, enabled: boolean): void {
    const bookings = this.getBookings().map(b => b.id === id ? { ...b, alarmSet: enabled } : b);
    localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(bookings));
    firestoreService.updateAppointmentStatus(id, 'confirmed', enabled).catch(console.warn);
  },

  cancelBooking(id: string): void {
    const bookings = this.getBookings();
    const target = bookings.find(b => b.id === id);
    if (target && target.status !== 'cancelled') {
      // Re-increment the slot
      const doctors = this.getDoctors();
      const doctor = doctors.find(d => d.id === target.doctorId);
      if (doctor) {
        const slot = doctor.timeSlots.find(s => s.time === target.timeSlot);
        if (slot) {
          slot.availableSlots = Math.min(slot.totalSlots, slot.availableSlots + 1);
          if (slot.availableSlots > 0) {
            slot.available = true;
          }
          this.saveDoctors(doctors);
        }
      }
    }

    const updated = bookings.map(b => b.id === id ? { ...b, status: 'cancelled' as const } : b);
    localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(updated));
    firestoreService.updateAppointmentStatus(id, 'cancelled').catch(console.warn);
  },

  // --- Document Vault ---
  getDocuments(): MedicalDocument[] {
    try {
      const data = localStorage.getItem(DOCUMENTS_STORAGE_KEY);
      if (!data) {
        localStorage.setItem(DOCUMENTS_STORAGE_KEY, JSON.stringify(initialSampleDocuments));
        return initialSampleDocuments;
      }
      return JSON.parse(data);
    } catch {
      return initialSampleDocuments;
    }
  },

  saveDocument(doc: MedicalDocument): void {
    const docs = this.getDocuments();
    docs.unshift(doc);
    localStorage.setItem(DOCUMENTS_STORAGE_KEY, JSON.stringify(docs));
    firestoreService.saveDocument(doc).catch(console.warn);
  },

  deleteDocument(id: string): void {
    const docs = this.getDocuments().filter(d => d.id !== id);
    localStorage.setItem(DOCUMENTS_STORAGE_KEY, JSON.stringify(docs));
    firestoreService.deleteDocument(id).catch(console.warn);
  },

  updateDocumentTitle(id: string, newTitle: string): void {
    const docs = this.getDocuments().map(d => d.id === id ? { ...d, title: newTitle.trim() } : d);
    localStorage.setItem(DOCUMENTS_STORAGE_KEY, JSON.stringify(docs));
    const target = docs.find(d => d.id === id);
    if (target) {
      firestoreService.saveDocument(target).catch(console.warn);
    }
  },

  // --- Feedback System ---
  getFeedback(): UserFeedback[] {
    try {
      const data = localStorage.getItem(FEEDBACK_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveFeedback(feedback: Omit<UserFeedback, 'id' | 'createdAt'>): UserFeedback {
    const all = this.getFeedback();
    const newFeedback: UserFeedback = {
      id: `fb-${Date.now()}`,
      createdAt: new Date().toISOString(),
      ...feedback,
    };
    all.unshift(newFeedback);
    localStorage.setItem(FEEDBACK_STORAGE_KEY, JSON.stringify(all));
    firestoreService.saveFeedback(newFeedback).catch(console.warn);
    return newFeedback;
  }
};
