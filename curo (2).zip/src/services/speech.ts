import { Language } from '../types';
import { apiService } from './api';

export interface SpeechRecognitionResultCallback {
  (transcript: string, isFinal: boolean): void;
}

export interface SpeechErrorCallback {
  (error: string, isPermissionDenied?: boolean): void;
}

export interface VoiceVolumeCallback {
  (volume: number): void;
}

export type VoiceStatus = 'idle' | 'requesting' | 'listening' | 'transcribing';

export class VoiceService {
  private recognition: any = null;
  private isListening: boolean = false;
  private currentLanguage: Language = 'en';
  private mediaStream: MediaStream | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private animFrameId: number | null = null;
  private speechTranscript: string = '';

  private onResultCallback: SpeechRecognitionResultCallback | null = null;
  private onErrorCallback: SpeechErrorCallback | null = null;
  private onEndCallback: (() => void) | null = null;
  private onVolumeCallback: VoiceVolumeCallback | null = null;
  private onStatusCallback: ((status: VoiceStatus) => void) | null = null;

  public isSupported(): boolean {
    return (
      (typeof window !== 'undefined' &&
        !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)) ||
      (typeof navigator !== 'undefined' &&
        !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia))
    );
  }

  public getLocale(lang: Language): string {
    switch (lang) {
      case 'te':
        return 'te-IN';
      case 'hi':
        return 'hi-IN';
      case 'en':
      default:
        return 'en-IN';
    }
  }

  public async startListening(
    lang: Language,
    onResult: SpeechRecognitionResultCallback,
    onError: SpeechErrorCallback,
    onEnd: () => void,
    onVolume?: VoiceVolumeCallback,
    onStatus?: (status: VoiceStatus) => void
  ): Promise<boolean> {
    if (this.isListening) {
      await this.stopListening();
    }

    this.currentLanguage = lang;
    this.onResultCallback = onResult;
    this.onErrorCallback = onError;
    this.onEndCallback = onEnd;
    this.onVolumeCallback = onVolume || null;
    this.onStatusCallback = onStatus || null;
    this.speechTranscript = '';
    this.audioChunks = [];

    this.onStatusCallback?.('requesting');

    // 1. Check mediaDevices availability
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      const msg = 'Microphone hardware access is not available in this browser environment.';
      this.onErrorCallback?.(msg, false);
      this.onStatusCallback?.('idle');
      return false;
    }

    // 2. Request user media stream with audio enhancements and graceful fallback
    try {
      try {
        this.mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
      } catch (constraintErr) {
        console.warn('Advanced audio constraints not supported, attempting basic audio...', constraintErr);
        // Fallback to basic audio stream
        this.mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: true,
        });
      }
    } catch (err: any) {
      console.warn('Microphone permission/access error:', err);
      const isPermissionDenied =
        err.name === 'NotAllowedError' ||
        err.name === 'PermissionDeniedError' ||
        err.name === 'SecurityError';
      const msg = isPermissionDenied
        ? 'Microphone access denied. Please click the lock/settings icon in your browser address bar to allow microphone access.'
        : `Could not access microphone: ${err.message || 'Device error'}`;
      this.onErrorCallback?.(msg, isPermissionDenied);
      this.onStatusCallback?.('idle');
      return false;
    }

    this.isListening = true;
    this.onStatusCallback?.('listening');

    // 3. Setup real-time AudioContext Volume Visualizer
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx && this.mediaStream) {
        this.audioContext = new AudioCtx();
        const source = this.audioContext.createMediaStreamSource(this.mediaStream);
        this.analyser = this.audioContext.createAnalyser();
        this.analyser.fftSize = 256;
        source.connect(this.analyser);

        const buffer = new Uint8Array(this.analyser.frequencyBinCount);
        const reportVolume = () => {
          if (!this.isListening || !this.analyser) return;
          this.analyser.getByteFrequencyData(buffer);
          let sum = 0;
          for (let i = 0; i < buffer.length; i++) {
            sum += buffer[i];
          }
          const avg = sum / buffer.length;
          // Scale to 0-100
          const volume = Math.min(100, Math.round((avg / 128) * 100));
          if (this.onVolumeCallback) {
            this.onVolumeCallback(volume);
          }
          this.animFrameId = requestAnimationFrame(reportVolume);
        };
        this.animFrameId = requestAnimationFrame(reportVolume);
      }
    } catch (e) {
      console.warn('AudioContext metering warning:', e);
    }

    // 4. Setup MediaRecorder for universal AI transcription fallback
    try {
      const mimeTypes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/ogg;codecs=opus',
        'audio/ogg',
        'audio/mp4',
      ];
      let selectedMime = '';
      if (typeof MediaRecorder !== 'undefined') {
        for (const type of mimeTypes) {
          if (MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(type)) {
            selectedMime = type;
            break;
          }
        }

        this.mediaRecorder = selectedMime
          ? new MediaRecorder(this.mediaStream, { mimeType: selectedMime })
          : new MediaRecorder(this.mediaStream);

        this.mediaRecorder.ondataavailable = (event: BlobEvent) => {
          if (event.data && event.data.size > 0) {
            this.audioChunks.push(event.data);
          }
        };

        this.mediaRecorder.start(250);
      }
    } catch (recorderErr) {
      console.warn('MediaRecorder initialization warning:', recorderErr);
    }

    // 5. Initialize Web Speech API for instantaneous real-time typing
    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognitionClass) {
      try {
        this.recognition = new SpeechRecognitionClass();
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.maxAlternatives = 1;
        this.recognition.lang = this.getLocale(lang);

        this.recognition.onresult = (event: any) => {
          let interim = '';
          let final = '';
          for (let i = 0; i < event.results.length; i++) {
            if (event.results[i].isFinal) {
              final += event.results[i][0].transcript + ' ';
            } else {
              interim += event.results[i][0].transcript;
            }
          }
          if (final.trim()) {
            this.speechTranscript = final.trim();
          }
          const full = (final + interim).trim();
          if (full && this.onResultCallback) {
            this.onResultCallback(full, false);
          }
        };

        this.recognition.onerror = (event: any) => {
          // If error occurs (network or not-allowed in iframes), we do NOT crash
          // because MediaRecorder is actively capturing the audio chunks!
          console.warn('SpeechRecognition status warning:', event?.error);
        };

        this.recognition.onend = () => {
          // Natural speech pause
        };

        this.recognition.start();
      } catch (speechErr) {
        console.warn('Web Speech API start warning:', speechErr);
      }
    }

    return true;
  }

  public async stopListening(): Promise<void> {
    if (!this.isListening) return;
    this.isListening = false;

    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.onVolumeCallback) {
      this.onVolumeCallback(0);
    }

    // Stop Web Speech Recognition
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (e) {
        // ignore
      }
      this.recognition = null;
    }

    this.onStatusCallback?.('transcribing');

    // Collect recorded audio blob
    let recordedBlob: Blob | null = null;
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      try {
        const stopPromise = new Promise<void>((resolve) => {
          if (!this.mediaRecorder) return resolve();
          this.mediaRecorder.onstop = () => resolve();
          this.mediaRecorder.stop();
        });
        await stopPromise;
      } catch (e) {
        console.warn('MediaRecorder stop warning:', e);
      }
    }

    if (this.audioChunks.length > 0) {
      const mime = (this.mediaRecorder && this.mediaRecorder.mimeType) || 'audio/webm';
      recordedBlob = new Blob(this.audioChunks, { type: mime });
    }

    // Release microphone tracks so browser hardware light turns off
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    if (this.audioContext) {
      try {
        this.audioContext.close();
      } catch (e) {
        // ignore
      }
      this.audioContext = null;
      this.analyser = null;
    }

    // Case 1: Real-time Web Speech transcribed speech
    if (this.speechTranscript && this.speechTranscript.trim().length > 0) {
      this.onResultCallback?.(this.speechTranscript.trim(), true);
      this.onStatusCallback?.('idle');
      this.onEndCallback?.();
      return;
    }

    // Case 2: Use Gemini AI Audio Transcription for high accuracy in Telugu, Hindi, English
    if (recordedBlob && recordedBlob.size > 800) {
      try {
        const aiText = await apiService.transcribeAudio(recordedBlob, this.currentLanguage);
        if (aiText && aiText.trim().length > 0) {
          this.onResultCallback?.(aiText.trim(), true);
          this.onStatusCallback?.('idle');
          this.onEndCallback?.();
          return;
        }
      } catch (aiErr) {
        console.warn('AI speech-to-text error:', aiErr);
      }
    }

    // Case 3: No discernible voice
    this.onErrorCallback?.(
      'No speech detected. Please speak closer to your microphone or switch to typing.',
      false
    );
    this.onStatusCallback?.('idle');
    this.onEndCallback?.();
  }

  public speak(text: string, lang: Language): void {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    window.speechSynthesis.cancel();

    const cleanText = text
      .replace(/[*#_`]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = this.getLocale(lang);
    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    const voices = window.speechSynthesis.getVoices();
    const targetLangCode = this.getLocale(lang).toLowerCase();
    const matchingVoice = voices.find((v) =>
      v.lang.toLowerCase().startsWith(targetLangCode.split('-')[0])
    );
    if (matchingVoice) {
      utterance.voice = matchingVoice;
    }

    window.speechSynthesis.speak(utterance);
  }

  public stopSpeaking(): void {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  }

  public async requestMicrophonePermission(): Promise<{ granted: boolean; error?: string }> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      return { granted: false, error: 'Microphone hardware access is not supported in this browser.' };
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop());
      const current = apiService.getPermissions();
      apiService.savePermissions({
        ...current,
        voiceAllowed: true,
        microphoneAllowed: true,
      });
      return { granted: true };
    } catch (err: any) {
      console.warn('Microphone permission request error:', err);
      const isDenied =
        err.name === 'NotAllowedError' ||
        err.name === 'PermissionDeniedError' ||
        err.name === 'SecurityError';
      return {
        granted: false,
        error: isDenied
          ? 'Microphone access denied. Please click the lock/settings icon in your browser address bar to allow microphone access.'
          : `Microphone error: ${err.message || 'Unknown issue'}`,
      };
    }
  }
}

export const voiceService = new VoiceService();
