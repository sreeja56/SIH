import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from './firebase';
import { UserProfile, Appointment, MedicalDocument, TriageResult, UserFeedback, Doctor } from '../types';

export const firestoreService = {
  // --- USERS ---
  async saveUser(user: UserProfile): Promise<void> {
    try {
      const docId = user.phone ? user.phone.replace(/\D/g, '') : (user.username || `user-${Date.now()}`);
      const userRef = doc(db, 'users', docId);
      await setDoc(userRef, {
        ...user,
        updatedAt: new Date().toISOString(),
        syncedAt: serverTimestamp(),
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore: saveUser error:', err);
    }
  },

  async fetchUsers(): Promise<UserProfile[]> {
    try {
      const usersCol = collection(db, 'users');
      const snap = await getDocs(usersCol);
      const list: UserProfile[] = [];
      snap.forEach((d) => {
        list.push(d.data() as UserProfile);
      });
      return list;
    } catch (err) {
      console.warn('Firestore: fetchUsers error:', err);
      return [];
    }
  },

  async getUser(phoneOrUsername: string): Promise<UserProfile | null> {
    try {
      const cleanPhone = phoneOrUsername.replace(/\D/g, '');
      if (cleanPhone) {
        const userRef = doc(db, 'users', cleanPhone);
        const snap = await getDoc(userRef);
        if (snap.exists()) {
          return snap.data() as UserProfile;
        }
      }
      return null;
    } catch (err) {
      console.warn('Firestore: getUser error:', err);
      return null;
    }
  },

  // --- APPOINTMENTS / BOOKINGS ---
  async saveAppointment(appointment: Appointment): Promise<void> {
    try {
      const docRef = doc(db, 'appointments', appointment.id);
      await setDoc(docRef, {
        ...appointment,
        syncedAt: serverTimestamp(),
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore: saveAppointment error:', err);
    }
  },

  async fetchAppointments(): Promise<Appointment[]> {
    try {
      const col = collection(db, 'appointments');
      const snap = await getDocs(col);
      const list: Appointment[] = [];
      snap.forEach((d) => {
        list.push(d.data() as Appointment);
      });
      return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch (err) {
      console.warn('Firestore: fetchAppointments error:', err);
      return [];
    }
  },

  async updateAppointmentStatus(id: string, status: Appointment['status'], alarmSet?: boolean): Promise<void> {
    try {
      const docRef = doc(db, 'appointments', id);
      const updateData: any = { status };
      if (alarmSet !== undefined) {
        updateData.alarmSet = alarmSet;
      }
      await setDoc(docRef, updateData, { merge: true });
    } catch (err) {
      console.warn('Firestore: updateAppointmentStatus error:', err);
    }
  },

  // --- MEDICAL DOCUMENTS VAULT ---
  async saveDocument(document: MedicalDocument): Promise<void> {
    try {
      const docRef = doc(db, 'documents', document.id);
      await setDoc(docRef, {
        ...document,
        syncedAt: serverTimestamp(),
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore: saveDocument error:', err);
    }
  },

  async fetchDocuments(): Promise<MedicalDocument[]> {
    try {
      const col = collection(db, 'documents');
      const snap = await getDocs(col);
      const list: MedicalDocument[] = [];
      snap.forEach((d) => {
        list.push(d.data() as MedicalDocument);
      });
      return list;
    } catch (err) {
      console.warn('Firestore: fetchDocuments error:', err);
      return [];
    }
  },

  async deleteDocument(id: string): Promise<void> {
    try {
      const docRef = doc(db, 'documents', id);
      await deleteDoc(docRef);
    } catch (err) {
      console.warn('Firestore: deleteDocument error:', err);
    }
  },

  // --- CLINICAL TRIAGE HISTORIES ---
  async saveTriageResult(triage: TriageResult): Promise<void> {
    try {
      const docRef = doc(db, 'triage_results', triage.id);
      await setDoc(docRef, {
        ...triage,
        createdAt: new Date().toISOString(),
        syncedAt: serverTimestamp(),
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore: saveTriageResult error:', err);
    }
  },

  // --- USER REVIEWS & FEEDBACK ---
  async saveFeedback(feedback: UserFeedback): Promise<void> {
    try {
      const docRef = doc(db, 'feedback', feedback.id);
      await setDoc(docRef, {
        ...feedback,
        syncedAt: serverTimestamp(),
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore: saveFeedback error:', err);
    }
  },

  async fetchFeedback(): Promise<UserFeedback[]> {
    try {
      const col = collection(db, 'feedback');
      const snap = await getDocs(col);
      const list: UserFeedback[] = [];
      snap.forEach((d) => {
        list.push(d.data() as UserFeedback);
      });
      return list;
    } catch (err) {
      console.warn('Firestore: fetchFeedback error:', err);
      return [];
    }
  },
};
